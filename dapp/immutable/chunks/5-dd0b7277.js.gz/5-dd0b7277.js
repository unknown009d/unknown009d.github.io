import{default as t}from"../components/pages/works/_page.svelte-a783e80d.js";export{t as component};
