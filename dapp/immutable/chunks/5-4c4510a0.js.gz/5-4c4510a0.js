import{default as t}from"../components/pages/projects/_page.svelte-101ed715.js";export{t as component};
