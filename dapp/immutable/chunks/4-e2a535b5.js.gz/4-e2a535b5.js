import{default as t}from"../components/pages/myresume/_page.svelte-e40db30b.js";export{t as component};
