import{default as t}from"../components/pages/_error.svelte-868760a6.js";export{t as component};
