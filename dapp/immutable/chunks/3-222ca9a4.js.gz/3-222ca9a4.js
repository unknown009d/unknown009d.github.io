import{default as t}from"../components/pages/aboutme/_page.svelte-95675008.js";export{t as component};
