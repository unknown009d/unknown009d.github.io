import{default as t}from"../components/pages/_layout.svelte-61d737a3.js";export{t as component};
