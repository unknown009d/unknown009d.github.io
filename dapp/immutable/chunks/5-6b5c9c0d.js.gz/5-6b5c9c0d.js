import{default as t}from"../components/pages/projects/_page.svelte-df133920.js";export{t as component};
