import{default as t}from"../components/pages/projects/_page.svelte-07b9d31f.js";export{t as component};
