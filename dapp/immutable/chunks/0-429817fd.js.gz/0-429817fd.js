import{default as t}from"../components/pages/_layout.svelte-9dce2ff0.js";export{t as component};
