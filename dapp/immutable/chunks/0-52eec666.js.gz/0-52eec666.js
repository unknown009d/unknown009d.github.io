import{default as t}from"../components/pages/_layout.svelte-06610c98.js";export{t as component};
