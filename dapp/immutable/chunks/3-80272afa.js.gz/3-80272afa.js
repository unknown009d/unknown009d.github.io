import{default as t}from"../components/pages/aboutme/_page.svelte-e46f6d4a.js";export{t as component};
