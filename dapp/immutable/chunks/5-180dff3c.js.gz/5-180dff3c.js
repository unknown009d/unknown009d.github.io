import{default as t}from"../components/pages/projects/_page.svelte-f08547b4.js";export{t as component};
