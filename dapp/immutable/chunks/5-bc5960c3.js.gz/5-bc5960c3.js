import{default as t}from"../components/pages/projects/_page.svelte-67d2a637.js";export{t as component};
