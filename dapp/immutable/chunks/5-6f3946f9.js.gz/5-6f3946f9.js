import{default as t}from"../components/pages/projects/_page.svelte-3ca5f0b8.js";export{t as component};
