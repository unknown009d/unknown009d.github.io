import{default as t}from"../components/pages/projects/_page.svelte-7d32793d.js";export{t as component};
