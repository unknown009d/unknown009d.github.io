import{default as t}from"../components/pages/myresume/_page.svelte-47b00ba5.js";export{t as component};
