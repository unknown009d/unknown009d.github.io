import{default as t}from"../components/pages/_layout.svelte-f4e69853.js";export{t as component};
