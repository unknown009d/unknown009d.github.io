import{default as t}from"../components/pages/myresume/_page.svelte-ba16d44e.js";export{t as component};
