import{default as t}from"../components/pages/_error.svelte-a2bf7d02.js";export{t as component};
