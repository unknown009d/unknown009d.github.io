import{_ as r}from"./_page-da46b06b.js";import{default as t}from"../components/pages/_page.svelte-384a5c75.js";export{t as component,r as universal};
