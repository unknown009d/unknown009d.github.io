import{default as t}from"../components/pages/_layout.svelte-9b6f3d6c.js";export{t as component};
