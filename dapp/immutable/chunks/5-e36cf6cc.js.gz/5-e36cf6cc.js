import{default as t}from"../components/pages/projects/_page.svelte-157a4a8e.js";export{t as component};
