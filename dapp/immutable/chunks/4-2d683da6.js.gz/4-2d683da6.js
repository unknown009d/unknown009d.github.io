import{default as t}from"../components/pages/myresume/_page.svelte-b0d14612.js";export{t as component};
