import{default as t}from"../components/pages/projects/_page.svelte-3975e86f.js";export{t as component};
