import{default as t}from"../components/pages/myresume/_page.svelte-059c771f.js";export{t as component};
