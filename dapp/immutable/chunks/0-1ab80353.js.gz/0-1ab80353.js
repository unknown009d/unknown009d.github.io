import{default as t}from"../components/pages/_layout.svelte-5f4a8455.js";export{t as component};
