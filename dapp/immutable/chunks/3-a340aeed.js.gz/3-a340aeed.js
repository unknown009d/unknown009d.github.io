import{default as t}from"../components/pages/aboutme/_page.svelte-d9154742.js";export{t as component};
