import{default as t}from"../components/pages/myresume/_page.svelte-498ab410.js";export{t as component};
