import{default as t}from"../components/pages/aboutme/_page.svelte-a9f1f0bb.js";export{t as component};
