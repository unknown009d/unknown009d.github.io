import{default as t}from"../components/pages/myresume/_page.svelte-e4001873.js";export{t as component};
