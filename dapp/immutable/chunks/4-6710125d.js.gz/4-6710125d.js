import{default as t}from"../components/pages/myresume/_page.svelte-926c2f2d.js";export{t as component};
