import{default as t}from"../components/pages/aboutme/_page.svelte-64324755.js";export{t as component};
