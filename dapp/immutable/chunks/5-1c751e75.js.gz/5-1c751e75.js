import{default as t}from"../components/pages/works/_page.svelte-ec611797.js";export{t as component};
