import{default as t}from"../components/pages/myresume/_page.svelte-a03ca7d8.js";export{t as component};
