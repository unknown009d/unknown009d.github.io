import{default as t}from"../components/pages/myresume/_page.svelte-86163766.js";export{t as component};
