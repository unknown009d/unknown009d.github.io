import{default as t}from"../components/pages/_error.svelte-e875e251.js";export{t as component};
