import{default as t}from"../components/pages/myresume/_page.svelte-4a11cdf8.js";export{t as component};
