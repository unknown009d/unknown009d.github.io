import{default as t}from"../components/pages/aboutme/_page.svelte-822a2215.js";export{t as component};
