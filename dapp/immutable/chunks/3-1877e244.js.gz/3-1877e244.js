import{default as t}from"../components/pages/aboutme/_page.svelte-fb55112d.js";export{t as component};
