import{default as t}from"../components/pages/myresume/_page.svelte-710ba5bc.js";export{t as component};
