import{default as t}from"../components/pages/_layout.svelte-5ca2ed7c.js";export{t as component};
