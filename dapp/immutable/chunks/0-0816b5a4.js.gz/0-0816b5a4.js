import{default as t}from"../components/pages/_layout.svelte-688330c1.js";export{t as component};
