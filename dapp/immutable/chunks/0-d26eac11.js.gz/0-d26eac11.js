import{default as t}from"../components/pages/_layout.svelte-25109650.js";export{t as component};
