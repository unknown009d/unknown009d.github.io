import{default as t}from"../components/pages/_layout.svelte-e049052f.js";export{t as component};
