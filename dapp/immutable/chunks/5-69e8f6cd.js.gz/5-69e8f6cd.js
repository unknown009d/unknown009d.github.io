import{default as t}from"../components/pages/projects/_page.svelte-465e3722.js";export{t as component};
