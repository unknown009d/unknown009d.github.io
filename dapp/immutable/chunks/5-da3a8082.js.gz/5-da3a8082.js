import{default as t}from"../components/pages/projects/_page.svelte-e9596542.js";export{t as component};
