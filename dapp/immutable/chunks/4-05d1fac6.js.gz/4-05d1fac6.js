import{default as t}from"../components/pages/myresume/_page.svelte-b862b7c7.js";export{t as component};
