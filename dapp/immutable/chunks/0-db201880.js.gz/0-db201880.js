import{default as t}from"../components/pages/_layout.svelte-49b96d10.js";export{t as component};
