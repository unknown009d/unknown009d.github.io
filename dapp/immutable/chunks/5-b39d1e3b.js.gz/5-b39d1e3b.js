import{default as t}from"../components/pages/projects/_page.svelte-ec3965ae.js";export{t as component};
