import{default as t}from"../components/pages/aboutme/_page.svelte-73bf7500.js";export{t as component};
