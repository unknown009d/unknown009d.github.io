import{default as t}from"../components/pages/aboutme/_page.svelte-22911412.js";export{t as component};
