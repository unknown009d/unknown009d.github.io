import{default as t}from"../components/pages/_error.svelte-5a999b5b.js";export{t as component};
