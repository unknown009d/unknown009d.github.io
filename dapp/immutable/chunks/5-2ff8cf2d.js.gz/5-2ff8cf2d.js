import{default as t}from"../components/pages/projects/_page.svelte-33c48fa8.js";export{t as component};
