import{default as t}from"../components/pages/myresume/_page.svelte-e83a129b.js";export{t as component};
