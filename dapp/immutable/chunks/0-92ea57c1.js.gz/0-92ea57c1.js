import{default as t}from"../components/pages/_layout.svelte-9b6d2c51.js";export{t as component};
