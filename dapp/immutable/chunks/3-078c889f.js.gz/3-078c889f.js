import{default as t}from"../components/pages/aboutme/_page.svelte-c1407acc.js";export{t as component};
