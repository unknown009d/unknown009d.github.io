import{default as t}from"../components/pages/aboutme/_page.svelte-e8005706.js";export{t as component};
