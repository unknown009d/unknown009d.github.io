import{default as t}from"../components/pages/projects/_page.svelte-4c2c2a91.js";export{t as component};
