import{default as t}from"../components/pages/_layout.svelte-b4dba08f.js";export{t as component};
