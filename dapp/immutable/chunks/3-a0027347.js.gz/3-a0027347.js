import{default as t}from"../components/pages/aboutme/_page.svelte-b7443547.js";export{t as component};
