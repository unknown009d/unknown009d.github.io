import{default as t}from"../components/pages/projects/_page.svelte-e9cdec97.js";export{t as component};
