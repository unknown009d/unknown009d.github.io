import{default as t}from"../components/pages/_layout.svelte-91cfa66b.js";export{t as component};
