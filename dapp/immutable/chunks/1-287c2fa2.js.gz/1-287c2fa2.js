import{default as t}from"../components/pages/_error.svelte-893f3e18.js";export{t as component};
