import{default as t}from"../components/pages/_layout.svelte-837bf0a8.js";export{t as component};
