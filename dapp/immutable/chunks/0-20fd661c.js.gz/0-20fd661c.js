import{default as t}from"../components/pages/_layout.svelte-25b6f98f.js";export{t as component};
