import{default as t}from"../components/pages/_error.svelte-44e9bf45.js";export{t as component};
