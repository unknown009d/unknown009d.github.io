import{default as t}from"../components/pages/myresume/_page.svelte-b4dbcd2a.js";export{t as component};
