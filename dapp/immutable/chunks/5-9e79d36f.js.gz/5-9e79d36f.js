import{default as t}from"../components/pages/works/_page.svelte-f5d445de.js";export{t as component};
