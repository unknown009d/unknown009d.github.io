import{default as t}from"../components/pages/myresume/_page.svelte-62e9fd4c.js";export{t as component};
