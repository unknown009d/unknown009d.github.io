import{default as t}from"../components/pages/myresume/_page.svelte-b72767ba.js";export{t as component};
