import{default as t}from"../components/pages/_layout.svelte-3ea08719.js";export{t as component};
