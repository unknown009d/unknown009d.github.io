import{default as t}from"../components/pages/_layout.svelte-593668f4.js";export{t as component};
