import{default as t}from"../components/pages/_layout.svelte-005b5b55.js";export{t as component};
