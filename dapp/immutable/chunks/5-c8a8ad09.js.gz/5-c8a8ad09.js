import{default as t}from"../components/pages/projects/_page.svelte-0435d1bd.js";export{t as component};
