import{default as t}from"../components/pages/aboutme/_page.svelte-15911994.js";export{t as component};
