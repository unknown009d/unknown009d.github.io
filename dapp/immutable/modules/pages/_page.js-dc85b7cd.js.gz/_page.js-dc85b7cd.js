import{p}from"../../chunks/_page-da46b06b.js";export{p as prerender};
