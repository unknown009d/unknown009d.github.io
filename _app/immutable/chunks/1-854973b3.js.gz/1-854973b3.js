import{default as t}from"../components/pages/_error.svelte-67d7c46a.js";export{t as component};
