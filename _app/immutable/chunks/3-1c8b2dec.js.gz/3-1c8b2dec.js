import{default as t}from"../components/pages/aboutme/_page.svelte-c7110278.js";export{t as component};
