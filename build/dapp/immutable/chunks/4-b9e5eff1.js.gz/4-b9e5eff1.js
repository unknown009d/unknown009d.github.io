import{default as t}from"../components/pages/myresume/_page.svelte-af10c65f.js";export{t as component};
