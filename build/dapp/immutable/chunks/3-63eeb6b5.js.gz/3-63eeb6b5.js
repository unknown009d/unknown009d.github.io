import{default as t}from"../components/pages/aboutme/_page.svelte-08d02752.js";export{t as component};
